# MessengerGUI
If you are looking for something like messenger in java , I tell you its not that.
Its just an example of Java Socket Programming, which is very loosely implemented, Lots of bugs and glitches.
It can only send messages within a same LAN of Wifi connected networks.

Usage:

Compile and Run - Server.java
Compile and Run - Messenger.java 
Remember to change Host IP with the server's IP adress

![Screenshot](https://raw.githubusercontent.com/r-0-0-t/MessengerGUI/master/Screenshot/Screenshot%20from%202018-09-24%2012-37-07.png "Screenshot")
